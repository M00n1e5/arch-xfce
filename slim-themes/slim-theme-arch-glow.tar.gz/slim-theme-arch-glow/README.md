SLIM login manager theme:
![screenshot](https://raw.githubusercontent.com/AnotherKamila/slim-theme-arch-glow/master/slim.png)
