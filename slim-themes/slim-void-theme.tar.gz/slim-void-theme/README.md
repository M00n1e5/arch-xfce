SLiM Display Manager theme for Void Linux
========================================


Preview:

![Preview](https://i.imgur.com/YSFNgPB.jpg)

